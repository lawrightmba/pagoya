# PTI Fairness-Analysis Bundle — Manifest

Packaged: 2026-07-09
Source commit: `1b2d787349e16c5aef2098a75770da5307ba124b`
Model version under audit: `PTI_MODEL_VERSION = "v4.3-signal-expansion"` (as read from `pti.ts`)
Fair-lending mapping version: computed dynamically via `computeMappingVersionHash()` in `fairLendingMapping.ts` (a hash of the current all-zero table — see Gap 3 below)

This bundle is **read-only** — every file below is an unmodified copy from the live codebase at the commit above. Nothing was edited to build this package.

---

## 1. Synthetic profile generator

| File | Role |
|---|---|
| `1-synthetic-generator/syntheticPopulation.ts` | Seeded PRNG (mulberry32) population generator. Defines behavioral segments (normal, cold_start_sparse, contradictory, gradient_sweep, gaming archetypes), latent reliability/engagement factors, and the latent-SES → colonia-tier / income-bucket coupling used to test disparate impact. |

**Generated dataset: NOT stored.** The 8,000-row population is generated in-memory on each run of the stress-test/ablation scripts from a fixed seed and is never persisted to disk (no dataset JSON/CSV exists in the repo or object storage). Anyone re-running `ptiStressTest.ts` or `ptiAblationStudy.ts` with the same seed reproduces the identical population deterministically — but there is no frozen snapshot of "the" 8,000 rows referenced in past reports. **This is the first documentation/implementation gap**: prior reports describe "the generated dataset" as if it were a fixed artifact; it is actually regenerated per run.

## 2. PTI v4.3 scoring logic

| File | Role |
|---|---|
| `2-scoring-logic/pti.ts` | Core engine. `buildPTISnapshotFromDb` (DB→snapshot mapper), `computePTI` (pure scoring function), the 4-dimension weights (PR 30 / BC 20 / ED 25 / CF 25), and `getPTITier` (tier cutoffs). |
| `2-scoring-logic/ptiDerivedFeatures.ts` | 15 of the v4.3-expansion signal computations (derived, non-DB-native). |
| `2-scoring-logic/ptiEventFeatures.ts` | Remaining v4.3-expansion signal computations sourced from event logs. |
| `2-scoring-logic/ptiV4_3Disposition.ts` | Disposition registry — documents why each of the 15 new fields ships at zero weight (5 permanent, 10 provisional pending real backtest data). |
| `2-scoring-logic/fairLendingAdjustment.ts` | The ±5 / ±2 adjustment layer: pass/conditional/fail classification, adjustment caps, and audit logging into `fair_lending_signoff`. |
| `2-scoring-logic/fairLendingMapping.ts` | The colonia-tier / income-bucket adjustment table consumed by the layer above. |

**Signal count note:** the "54 signals" figure = 39 standard signals computed inline in `computePTI` + 15 v4.3-expansion signals in the two feature files above. All 39 standard signals carry their documented weights; **all 15 expansion signals carry zero weight in production** (see `ptiV4_3Disposition.ts`), despite being fully computed and available. If any external summary described the v4.3 model as "54 weighted signals," that is inaccurate — 39 are weighted, 15 are computed-but-inert.

**Gap 2 — fair-lending layer is a no-op in production.** `fairLendingMapping.ts` defines `colonia_tier_adjustment` and `income_bucket_adjustment` as **all-zero placeholders**, each explicitly commented `// TODO: pending bias test`. The ±5/±2 adjustment code in `fairLendingAdjustment.ts` is real and wired in, but because every input mapping value is 0, it currently adjusts no one's score. Any documentation stating the fair-lending layer "corrects for" colonia/income disparity is describing intended future behavior, not current behavior. Note also the explicit regression guard referenced in `fairLendingMapping.ts` (line ~17-18): `computePTI()` must never import colonia/income data directly — the separation is intentional and enforced by a test, but it also means the correction is fully inert until real adjustment values are filled in.

## 3. Readiness gate

| File | Role |
|---|---|
| `3-readiness-gate/readinessGate.ts` | 6-criteria evaluation feeding `readiness_assessments`. |

Exact thresholds as implemented (pulled from code, not docs):
- **Hard gate (READY):** PTI ≥ 80, streak ≥ 90 days, bill-type diversity ≥ 3, literacy score ≥ 3, KYC verified, 0 fraud flags.
- **Soft gate (APPROACHING):** PTI ≥ 70, streak ≥ 60 days, plus all other hard criteria unchanged.

No discrepancy found here — the in-file doc comment states the same 80/90/3/3 and 70/60 figures as the executable constants (`HARD_PTI`, `HARD_STREAK_DAYS`, `HARD_DIVERSITY`, `HARD_LITERACY`, `SOFT_PTI`, `SOFT_STREAK_DAYS`).

## 4. Stress-test / ablation study

| File | Role |
|---|---|
| `4-stress-test/ptiStressTest.ts` | Original stress-test runner: score distribution, tier breakdown (real cutoffs 40/60/80), dimension means, cold-start segment analysis. |
| `4-stress-test/ptiAblationStudy.ts` | Follow-up disparate-impact ablation study. Its baseline step explicitly reproduces and checks against the original findings (`four-fifths ≈ 0.045`, `Cohen's d ≈ 0.90`), with a hard tolerance check (`|fourFifths−0.045|<0.03` and `|d−0.9|<0.15`) that fails loudly if a re-run doesn't land in the same place. |

**Output artifacts: NOT stored as files.** Both scripts are dev-only, no-DB, no-prod-contact, and emit their findings as console output (tables, histograms, printed ratios) at runtime — there are no `.json`/`.csv` result files checked into the repo for either script. This mirrors the Section 1 gap: the "0.045 / d≈0.90" figures live only as reproducible console output from a deterministic seed, not as a frozen results artifact. If a written report cites those numbers as coming from a saved output file, that file does not exist; the number was transcribed from a console run.

**Gap 3 — tier boundary documentation drift.** `ptiStressTest.ts` itself contains a comment flagging that an earlier project brief stated tier boundaries at 30/50/65/80, while the actual implementation in `pti.ts` (`getPTITier`) uses **40/60/80** (see line ~198 of `ptiStressTest.ts` and lines 662-667 of `pti.ts`). This bundle includes both the docstring comment and the executable cutoffs side by side for direct comparison — the code is authoritative; the 30/50/65/80 figure in any older brief is stale.

---

## Summary of flagged doc-vs-implementation gaps

1. **"Generated dataset" is not a fixed artifact.** It's regenerated in-memory per run from a seed; no frozen 8,000-row file exists anywhere in the codebase.
2. **Fair-lending ±5/±2 layer is currently inert.** Code and audit logging are real and wired in, but the colonia/income adjustment table it reads from is all zeros pending a bias-test sign-off — so in production it adjusts nothing.
3. **Tier boundaries drifted from an older brief (30/50/65/80) to the current implementation (40/60/80).** The stress-test script's own comments flag this; `pti.ts` is authoritative.
4. **Signal count framing.** "54 signals" is accurate as a count of computed signals, but only 39 are weighted; the other 15 (v4.3 expansion) are computed and logged but contribute zero to the score.
5. **Stress-test/ablation findings (0.045 / d≈0.90) exist only as console output**, not as saved result files — reproducible via the included scripts with the same seed, but not archived anywhere as data.
