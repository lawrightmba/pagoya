export type BillCategory =
  | "Luz"
  | "Agua"
  | "Gas"
  | "Internet"
  | "Cable"
  | "Teléfono móvil"
  | "Streaming"
  | "Gift Cards"
  | "Préstamos"
  | "Seguro"
  | "Escuela"
  | "Renta"
  | "Otro";

export type ProviderName = "siprel" | "evoluciona";

export interface BillService {
  id: string;
  name: string;
  category: BillCategory;
  providers: ProviderName[];
  logoEmoji: string;
  siprelServiceId?: string;
  evolucionaServiceId?: string;
  minReferencia?: number;
  maxReferencia?: number;
  minAmount?: number;
  isTopup?: boolean;
  isGiftCard?: boolean;   // Fixed-denomination digital voucher — no referencia required from user
  fixedAmount?: number;   // Enforced server-side; overrides any client-supplied monto
}

export interface BillPayRequest {
  serviceId: string;
  referencia: string;
  monto: number;
  telefono: string;
  notas?: string;
}

export interface BillPayResult {
  success: boolean;
  confirmationCode: string;
  provider: ProviderName;
  timestamp: string;
  failoverUsed: boolean;
  status?: "confirmed" | "pending" | "failed";
  rawResponse?: unknown;
}

export interface TaecelBalance {
  tiempoAire: number;
  pagoServicios: number;
}

export interface ProviderAdapter {
  name: ProviderName;
  isAvailable(): boolean;
  pay(service: BillService, req: BillPayRequest): Promise<BillPayResult>;
  getSaldoBalance?(): Promise<TaecelBalance>;
  getCatalog?(): Promise<unknown>;
  getTransactionStatus?(transID: string): Promise<unknown>;
}
